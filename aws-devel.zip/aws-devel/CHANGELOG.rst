===================
Ansible Network aws
===================

v2.6.0
==============

Major Changes
-------------

- Initial release of the ``aws`` Ansible role.

- This role provides functions to manage AWS.

