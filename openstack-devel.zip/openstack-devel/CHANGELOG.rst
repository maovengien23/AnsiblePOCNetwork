=====================
Ansible Network azure
=====================

v2.6.1
========

Minor Changes
-------------

- Parameterize instance size.


v2.6.0
======

Major Changes
-------------

- Initial release of the ``openstack`` Ansible role.

- This role provides functions to manage OpenStack.

