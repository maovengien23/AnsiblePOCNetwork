.. include:: ../../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   releasenotes

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
