Documentation:
==============
module_documentation: library/openconfig_parser.py
