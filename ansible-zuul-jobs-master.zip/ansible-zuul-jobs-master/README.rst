Ansible Zuul jobs
=================

This repo contains a set of ansible playbooks which are used by the
Ansible network project CI system Zuul. It also contains job and
project-template definitions for the Ansible network projects. You
should edit these files to make configuration changes to Ansible CI.
