.. include:: ../../README.rst

.. toctree::
   :maxdepth: 2

   jobs

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
