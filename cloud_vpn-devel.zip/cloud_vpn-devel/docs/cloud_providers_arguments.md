# Arguments

## cloud_vpn_initiator_image_id

This value sets the initiator image ID to use for provisioning the networking appliance.

## cloud_vpn_initiator_key_name

This value sets the initiator key name to inject to the networking appliance on provision.

## cloud_vpn_responder_image_id

This value sets the responder image ID to use for provisioning the networking appliance.

## cloud_vpn_responder_key_name

This value sets the responder key name to inject to the networking appliance on provision.
