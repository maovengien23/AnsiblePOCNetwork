# Arguments

## cloud_vpn_initiator_openstack_cloud

This value sets the OpenStack cloud for the initiator, per defined
in clouds.yaml file.

## cloud_vpn_initiator_external_network

This value sets the external network for the initiator.

## cloud_vpn_responder_openstack_cloud

This value sets the OpenStack cloud for the responder, per defined
in clouds.yaml file.

## cloud_vpn_responder_external_network

This value sets the external network for the responder.
