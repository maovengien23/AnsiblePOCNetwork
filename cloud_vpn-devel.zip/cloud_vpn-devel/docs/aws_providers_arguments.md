# Arguments

## cloud_vpn_initiator_aws_access_key

This value sets the AWS access key for the initiator.

## cloud_vpn_initiator_aws_secret_key

This value sets the AWS secret key for the initiator.

## cloud_vpn_initiator_aws_region

This value sets the AWS region for the initiator.

## cloud_vpn_responder_aws_access_key

This value sets the AWS access key for the responder.

## cloud_vpn_responder_aws_secret_key

This value sets the AWS secret key for the responder.

## cloud_vpn_responder_aws_region

This value sets the AWS region for the responder.
