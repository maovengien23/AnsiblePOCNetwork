# Arguments

## cloud_vpn_initiator_azure_region

This value sets the Azure region for the initiator.

## cloud_vpn_initiator_azure_subcription_id

This value sets the Azure subscription ID for the initiator.

## cloud_vpn_initiator_azure_tenant

This value sets the Azure tenant for the initiator.

## cloud_vpn_initiator_azure_client_id

This value sets the Azure client ID for the initiator.

## cloud_vpn_initiator_azure_secret

This value sets the Azure secret for the initiator.

## cloud_vpn_responder_azure_region

This value sets the Azure region for the responder.

## cloud_vpn_responder_azure_subcription_id

This value sets the Azure subscription ID for the responder.

## cloud_vpn_responder_azure_tenant

This value sets the Azure tenant for the responder.

## cloud_vpn_responder_azure_client_id

This value sets the Azure client ID for the responder.

## cloud_vpn_responder_azure_secret

This value sets the Azure secret for the responder.
