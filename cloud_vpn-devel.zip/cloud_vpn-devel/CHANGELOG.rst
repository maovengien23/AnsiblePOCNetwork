=========================
Ansible Network cloud_vpn
=========================

v2.6.2
=======

Minor Changes
-------------

- Decouple provisioners and providers on their own roles which
  will be available from Galaxy.

v2.6.1
=======

Minor Changes
-------------

- Rename meta/main.yaml to meta/main.yml to avoid Galaxy upload issues.

v2.6.0
======

Major Changes
-------------

- Initial release of the ``cloud_vpn`` Ansible role.

- This role provides functions to manage IPSEC VPN tunnels.

