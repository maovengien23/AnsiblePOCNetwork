# frr

This Ansible Network role provides a set of platform dependent fuctions that
are designed to work with devices running Free Range Routing. The functions included 
in this role inlcuding both configuration and fact collection.


## Requirements

* Ansible 2.7 or later
* Ansible Network Engine Role 2.6.2 or later

## License

GPLv3

## Author Information

Ansible Network Engineering Team



