=====================
Ansible Network azure
=====================

v2.6.0
======

Major Changes
-------------

- Initial release of the ``rhel`` Ansible role.

- This role provides functions to manage RHEL/CentOS.


